$(document).ready(function() {

	$('.selectpicker').selectpicker({
  		liveSearch: true,
  		dropupAuto: false
	});

	$('#slider-1').slider({
		formatter: function(value) {
			return value + ' years old';
		}
	});

});