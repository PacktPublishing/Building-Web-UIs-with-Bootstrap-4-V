$(document).ready(function() {

	// POPOVERS
	$('[data-toggle="popover"]').popover();

	// SWIPE CAROUSEL https://hammerjs.github.io/
	if($('#gallery').length) {
		var area = document.getElementById('gallery');   
	    var hammer = new Hammer(area);

	    hammer.on('swipeleft', function (e) {
	        $('#gallery').carousel('prev');
	    });

	    hammer.on('swiperight', function (e) {
	        $('#gallery').carousel('next');
	    });
	}

	// OFF CANVAS
	$('[data-toggle="offcanvas"]').on('click', function () {
    	$('.offcanvas-collapse').toggleClass('open');
  	});

	// PROGRAMATIC MODAL
	$('.show-login-modal').on('click', function(e) {
  		e.preventDefault();
  		$('#loginModal').modal('toggle');
	});

	$('#loginModal').on('shown.bs.modal', function (e) {
		$('#loginModal input[type="email"]').focus();
	});

	// BOOTSTRAP LIGHTBOX
	$(document).on('click', '[data-toggle="lightbox"]', function(event) {
	    event.preventDefault();
	    $(this).ekkoLightbox();
	});

	// BOOTSTRAP SELECT

	if($('.selectpicker').length) {
		$('.selectpicker').selectpicker({
	  		liveSearch: true,
	  		dropupAuto: false
		});
	}

	// BOOTSTRAP SLIDER
	if($('#slider-1').length) {
		$('#slider-1').slider({
			formatter: function(value) {
				return value + ' years old';
			}
		});
	}

	// BOOTSTRAP FILE INPUT
	if($('#profile-image-upload').length) {
		$('#profile-image-upload').fileinput({
			theme: 'fa'
		});
	}

	// BOOTSTRAP DATE TIME PICKER
	if($('#date-time-picker').length) {
		$('#date-time-picker').datetimepicker({
			//format: 'L'
			sideBySide: true
		});

		// DATE RANGE PICKER
	    function cb(start, end) {
	    	$('#range-picker span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
	    }

	    $('#range-picker').daterangepicker({
	        startDate: moment().subtract(29, 'days'),
	        endDate: moment(),
	        ranges: {
	           'Today': [moment(), moment()],
	           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
	           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
	           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
	           'This Month': [moment().startOf('month'), moment().endOf('month')],
	           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
	        }
	    }, cb);

	    cb(start, end);
	}

});

// NATIVE FORM VALIDATION
window.addEventListener('load', function() {

    var forms = document.getElementsByClassName('needs-validation');

    var validation = Array.prototype.filter.call(forms, function(form) {
    	form.addEventListener('submit', function(event) {
        
	        if(form.checkValidity() === false) {
	          event.preventDefault();
	          event.stopPropagation();
	        }

        	form.classList.add('was-validated');
      	}, false);
	});
}, false);